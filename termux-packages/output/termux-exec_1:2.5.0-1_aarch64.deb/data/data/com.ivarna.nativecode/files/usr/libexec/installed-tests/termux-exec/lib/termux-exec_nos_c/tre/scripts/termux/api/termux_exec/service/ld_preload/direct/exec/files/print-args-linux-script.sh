#!/data/data/com.ivarna.nativecode/files/usr/bin/sh

echo "$@"
